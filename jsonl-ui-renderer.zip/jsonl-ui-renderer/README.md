# JSONL UI Renderer

A declarative UI rendering system powered by LLM streaming. Send a natural language prompt, get back structured JSONL, and watch the UI build itself incrementally — component by component.

## 📦 What's Inside

```
jsonl-ui-renderer/
├── src/
│   ├── main.jsx          # React entry point
│   └── App.jsx           # React streaming renderer (main app)
├── public/
│   └── vue-renderer.html # Vue.js 3 standalone renderer
├── index.html            # Vite HTML entry
├── vite.config.js        # Vite configuration
├── package.json
└── README.md
```

**Two versions included:**

| Feature | React (App.jsx) | Vue (vue-renderer.html) |
|---|---|---|
| Framework | React 18 + Vite | Vue 3 (CDN, zero build) |
| Streaming | ✅ Incremental SSE | ❌ Batch response |
| Stop button | ✅ | ❌ |
| Run | `npm run dev` | Open file in browser |

## 🚀 Quick Start

### React Version (Recommended — has streaming)

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open http://localhost:3000
```

### Vue Version (Zero setup)

Just open `public/vue-renderer.html` directly in your browser. No build step needed — Vue 3 loads from CDN.

```bash
# Or serve it
npx serve public
```

## 🔑 API Key

Both versions call the Anthropic API directly from the browser. The API key is handled by the Anthropic proxy when running inside Claude artifacts. 

**To run locally**, you'll need to either:

1. Set up a proxy server that adds your API key, or
2. Modify the `fetch` call in the source to include your key:

```js
headers: {
  "Content-Type": "application/json",
  "x-api-key": "your-key-here",         // Add this
  "anthropic-version": "2023-06-01",     // Add this
}
```

## 📡 The Protocol

The system uses 4 JSONL message types:

### `beginRendering` — Create a surface
```json
{"beginRendering":{"surfaceId":"s1","root":"rootComponentId"}}
```

### `surfaceUpdate` — Add/update components
```json
{"surfaceUpdate":{"surfaceId":"s1","components":[
  {"id":"card1","component":{"Card":{"padding":"24px","children":["title1","body1"]}}},
  {"id":"title1","component":{"Heading":{"content":"Hello","level":2}}}
]}}
```

### `dataModelUpdate` — Set application state
```json
{"dataModelUpdate":{"surfaceId":"s1","contents":[
  {"key":"username","valueString":"alice"},
  {"key":"count","valueNumber":42}
]}}
```

### `deleteSurface` — Remove a surface
```json
{"deleteSurface":{"surfaceId":"s1"}}
```

## 🧱 Component Catalog (18 types)

**Containers** (support `children` array):
`Box` · `Card` · `List` · `Grid`

**Content:**
`Text` · `Heading` · `Image` · `Icon` · `Badge` · `Avatar`

**Inputs:**
`Button` · `Input` · `TextArea` · `Select` · `Toggle`

**Layout:**
`Divider` · `Spacer`

**Data:**
`Progress`

## 🌊 How Streaming Works (React version)

1. Prompt is sent to Claude with `stream: true`
2. SSE events are parsed via an async generator
3. Text chunks accumulate in a buffer
4. Each time `\n` completes a line → validate → apply to state
5. React re-renders the preview with the new component
6. Pending children show amber spinners until their data arrives
7. Each component fades in with a `compAppear` animation

## 🛠 Build for Production

```bash
npm run build    # Outputs to dist/
npm run preview  # Preview the build
```

## 📄 License

MIT
